use tests_build::tokio;

#[tokio::main]
async fn main() -> Result<(), ()> {
    return Ok(());
}
